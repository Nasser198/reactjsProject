import React from "react";
import "./App.css";
import ChatWindow from "./components/ChatWindow";

function App() {
    return (
        <>
            <ChatWindow />
        </>
    );
}

export default App;
